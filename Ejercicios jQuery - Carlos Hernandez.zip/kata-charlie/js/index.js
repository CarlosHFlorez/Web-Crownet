//CUANDO MOUSEOVER EN .ETIQUETAS-CONTAINER ELIMINAMOS LA CLASE ISACTIVE A TODAS Y
//AÑADIMOS LA CLASE IS ACTIVE A LA POSICION ACTUAL DEL ARRAY

$(`.Etiquetas-container`).mouseover(function () {
  let i = $(`.Etiquetas-container`).index($(this));
  $(`.Etiquetas-img`).removeClass(`isActive`);
  $(`.Etiquetas-img`).eq(i).addClass(`isActive`);
  $(`.Etiquetas-container`).mouseout(function () {
    $(`.Etiquetas-img`).eq(i).removeClass(`isActive`);
  });
});
