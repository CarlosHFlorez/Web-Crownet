//CUANDO CLICK EN GALERIA-IMG LE AÑADIMOS A LIGHTBOX-CONTAINER LA CLASE ISACTIVE
$(`.Galeria-img`).click(function () {
  $(`.Lightbox-container`).addClass(`isActive`);

  let source = $(`.Galeria-img`).attr(`src`);
  $(`.Lightbox-img`).attr(`src`, source);
});

//CUANDO HACEMOS CLICK EN lIGHTBOX-BTN QUITAMOS LA CLASE ISACTIVE DE LIGHTBOX CONTAINER
$(`.Lightbox-btn`).click(function () {
  $(`.Lightbox-container`).removeClass(`isActive`);
});
