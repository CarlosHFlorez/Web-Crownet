//CUANDO CLICK EN .INFO-SPAN ELIMINAMOS LA CLASE ISACTIVE DE TODOS Y SE LA AÑADIMOS AL
//.INDEX-P CORRESPONDIENTE

$(`.Index-span`).click(function () {
  let i = $(`.Index-span`).index($(this));
  $(`.Info-p`).removeClass(`isActive`);
  $(`.Info-p`).eq(i).toggleClass(`isActive`);
});
