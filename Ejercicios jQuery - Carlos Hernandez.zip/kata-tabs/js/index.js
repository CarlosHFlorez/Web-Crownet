//Cuando hagamos click en Tabs-li, le eliminamos la clase is Active a todos los Tabs-li y se la añadimos a la POSICION correspondiente

$(`.Tabs-li`).click(function () {
  let i = $(`.Tabs-li`).index($(this));
  $(`.Tabs-li`).removeClass(`isActive`);
  $(`.Tabs-li`).eq(i).addClass(`isActive`);
  $(`.Tabs-p`).removeClass(`isActive`);
  $(`.Tabs-p`).eq(i).addClass(`isActive`);
});
